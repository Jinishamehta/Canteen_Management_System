<?php

// Create customized config variables
$config['web_Address']= 'https://www.formget.com/blog';
$config['title']= 'CodeIgniter Global Variable';

?>