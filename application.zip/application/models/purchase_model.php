<?php 

class Purchase_model extends CI_Model {

	public function get_orders_by_user($user_id){

		if($this->session->userdata('user_type')){

			$sql = "SELECT z_orders.id,z_orders.company_id,z_orders.status,z_users.first_name FROM z_orders LEFT JOIN z_users ON z_orders.user_id = z_users.id";
			$query = $this->db->query($sql);
			
			return $query->result();
		}else{
			$this->db->where('user_id',$user_id);
			$query = $this->db->get('z_orders');
			return $query->result();
		}
		
	}

	public function view_order($order_id){

		$this->db->where('order_id',$order_id);
		$query=$this->db->get('z_order_details');
		return $query->result();
	}

	public function get_all_products(){

		$query = $this->db->get('z_products');
		return $query->result();
	}

	public function get_price($product_id){

		$this->db->where('id',$product_id);
		$get_data = $this->db->get('z_products');        
        return $get_data->row();
    }

    public function add_order($data){

    	$insert_query = $this->db->insert('z_orders',$data);
		return $insert_query;
    }

    public function add_order_list($data,$order_id){
		if(is_null($data)){
    		return false;
    	}
		else{
			foreach ($data as $key => $value) {
				$details = array(
					'order_id' => $order_id,
					'product_id'=> $value[0],
					'price'=>$value[1],
					'quantity'=>$value[2]
					);
				$insert_query = $this->db->insert('z_order_details',$details);
			}
			return true;
    	}
	}

	public function order_id(){
		$query = $this->db->query("SELECT * FROM z_orders ORDER BY id DESC LIMIT 1");
		$result = $query->result_array();
		$offset = 0;
		if(empty($result))
			return $offset;
		else
			return $result[0]['id'];
	}
}

 ?>
