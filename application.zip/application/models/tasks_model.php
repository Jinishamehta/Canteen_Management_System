<?php 

class Tasks_model extends CI_Model {


//display all task
	public function get_all_task(){

		$query = $this->db->get('z_robot_task');
		return $query->result();
	}

//get order id for dropdown
	public function get_orders($user_id){

		$this->db->where('user_id',$user_id);
		$query = $this->db->get('z_purchase');

		return $query->result();
	}

//get location fo rdropdown
	public function get_location(){

	
		$query = $this->db->get('z_location_pick');
		return $query->result();

	}

	//get current location
	public function get_location_2($task_id){

		$this->db->where('id',$task_id);
		$query = $this->db->get('z_robot_task');
		return $query->row()->location;

	}

	//get current order id
	public function get_order_id($task_id){

		$this->db->where('id',$task_id);
		$query = $this->db->get('z_robot_task');

		return $query->row()->order_id;

	}

	//update the task
	public function edit_task($task_id,$data){

		$this->db->where('id',$task_id);
		$update_query = $this->db->update('z_robot_task',$data);
		return $update_query;

	}

	//create new task
	public function create_task($data) {

		$this->db->where('status','0');
		$insert_query = $this->db->insert('z_robot_task',$data);
		return $insert_query;
	}

	//get a completion signal for order
	public function mark_complete($location_id,$order_id){

		$this->db->set('status',1);
		$this->db->where('id',$order_id);
		$data = $this->db->update('z_purchase');

		$this->db->set('status',1);
		$this->db->where('id',$location_id);
		$data = $this->db->update('z_location_pick');
		return $data;
	}

	//get a scanned list by robot
	public function get_scanned_list($data){

		$this->db->where('order_id',$data);
		$query = $this->db->get('z_scanned');
		return $query->result();
	}

	//compare scanned and actual list for difference
	public function comparing_lists($data){

		$sql = "SELECT product_id,price,quantity FROM( SELECT product_id,price,quantity FROM z_purchase_details WHERE order_id = '$data' UNION ALL SELECT product_id,price,quantity FROM z_scanned WHERE order_id = '$data')tb1 GROUP BY product_id,price,quantity HAVING count(*) = 1 ORDER BY product_id";

		$query = $this->db->query($sql);
		if($query->num_rows() == 0)
		{
			$this->db->where('order_id',$data);
			$data_1 = $this->db->get('z_robot_task');
			$b = $data_1->result();
			foreach ($b as $key) {
				$f = $key->status;
			}
			if($f)
				return $query->result(); 
			else{
			$this->db->where('order_id',$data);
			$q = $this->db->get('z_purchase_details');
			$a = $q->result();
			foreach ($a as $s) {
				$this->db->where('id',$s->product_id);
				$qty = $this->db->get('z_products');
				$x = $qty->row()->quantity + $s->quantity;
				$d = array(
					'quantity' => $x);
				$this->db->where('id',$s->product_id);
				$this->db->update('z_products',$d);
				# code...
			}
			$this->db->set('status',1);
			$this->db->where('order_id',$data);
			$data = $this->db->update('z_robot_task');

							return $query->result();  }

		}else
			return $query->result();

	}

	public function update_inventory($data){

		$this->db->where('order_id',$data);
		$query = $this->db->get('z_purchase_details');
		return $query->result();
	}
}

 ?>