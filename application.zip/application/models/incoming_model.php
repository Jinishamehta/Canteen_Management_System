<?php 

class Incoming_model extends CI_Model {

	public function get_all_orders($user_id){

		$this->db->where('user_id',$user_id);
		$query = $this->db->get('z_purchase');
		return $query->result();
	}

	public function get_all_products(){

		$query = $this->db->get('z_products');
		return $query->result();
	}

	public function get_price($product_id){

		$this->db->where('id',$product_id);
		$get_data = $this->db->get('z_products');        
        return $get_data->row();
    }

    public function save($data){
   	
   		$insert_query = $this->db->insert('z_purchase',$data);
		return $insert_query;
	}

	public function check($data,$order_id){
		if(is_null($data)){
    		return false;
    	}
		else{
			foreach ($data as $key => $value) {
				$details = array(
					'order_id' => $order_id,
					'product_id'=> $value[0],
					'price'=>$value[1],
					'quantity'=>$value[2]
					);
				$insert_query = $this->db->insert('z_purchase_details',$details);
			}
			return true;
    	}
	}

	public function get_specific_orders($order_id){

		$this->db->where('order_id',$order_id);
		$query = $this->db->get('z_purchase_details');
		return $query->result();
	}

	public function order_id(){
		$query = $this->db->query("SELECT * FROM z_purchase ORDER BY id DESC LIMIT 1");
		$result = $query->result_array();
		$offset = 0;
		if(empty($result))
			return $offset;
		else
			return $result[0]['id'];
	}
}

 ?>
