<?php

class Inventory_model extends CI_Model {

	public function get_inventory() {

		$query = $this->db->get('z_products');
		return $query->result();
	}

	public function add_product($data){

		$query = $this->db->insert('z_products',$data);
		return $query;
	}

}

	
 

?>