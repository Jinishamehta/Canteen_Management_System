<?php

class Robots extends CI_Controller {
	
	

	public function __construct(){

		parent::__construct();

		if(!$this->session->userdata('logged_in')){

			$this->session->set_flashdata('no_access','Sorry you are not allowed or not logged in');
			redirect('home/index');
		}
	}
	
	public function index() {

		$data['inventory'] = $this->robot_model->get_robots();
		

		$data['main_view'] = "inventory/index";

		$this->load->view('layouts/main', $data);

	}
}

 ?>
