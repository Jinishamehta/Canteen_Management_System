<?php 


class Incoming extends CI_Controller {

	public function __construct(){

		parent::__construct();

		if(!$this->session->userdata('logged_in')){

			$this->session->set_flashdata('no_access','Sorry you are not allowed or not logged in');
			redirect('home/index');
		}
	}
	
	public function index() {

		$user_id = $this->session->userdata('user_id');
		$data['orders'] = $this->incoming_model->get_all_orders($user_id);
		if(isset($data['orders'])){
			$data['main_view'] = "incoming/display";
			$this->load->view('layouts/main', $data);
		}else{
			$raw['main_view'] = "incoming/display_for_no_order";
			$this->load->view('layouts/main', $raw);
		}

	}

	public function order(){
		$data = $_POST['id'];
		$orderid = $_POST['order'];
		$status = $this->incoming_model->check($data,$orderid);
		return $status;
	}

	 public function create_order() {

		$this->form_validation->set_rules('company_id', 'Company ID', 'trim|required' );
		
		if($this->form_validation->run() == FALSE){

			$last_row = $this->incoming_model->order_id();
			$data['order_id'] = $last_row + 1;
			$data['orders'] = $this->incoming_model->get_all_products();
			$data['main_view'] = 'incoming/create_order';
			$this->load->view('layouts/main',$data);
		}else{
			
			 $data = array(
			 		'user_id' => $this->session->userdata('user_id'),
			 		'company_id' => $this->input->post('company_id')
					);
			if($this->incoming_model->save($data)) {
				redirect("incoming");
			}
		}
	}

	

	public function get_product_price(){
		$product_id = $this->input->post('id',TRUE);
        $data = $this->incoming_model->get_price($product_id);
        echo $data->price; 
        // return $data->price;
	}

	public function get_orders($order_id){

		$data['orders'] = $this->incoming_model->get_specific_orders($order_id);
		$data['main_view'] = "incoming/display_products";
		$this->load->view('layouts/main', $data);

	}
}

 ?>