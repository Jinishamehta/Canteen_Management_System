<?php

class Purchase extends CI_Controller {
	
	public function __construct(){

		parent::__construct();

		if(!$this->session->userdata('logged_in')){
			$this->session->set_flashdata('no_access','Sorry you are not allowed or not logged in');
			redirect('home/index');
		}
	}
	
	public function index() {

		$user_id = $this->session->userdata('user_id');
		$data['orders'] = $this->purchase_model->get_orders_by_user($user_id);
		$data['main_view'] = "purchase/Display";
		$this->load->view('layouts/main', $data);

	}

	public function get_order($order_id){

		$data['orders'] = $this->purchase_model->view_order($order_id);

		$data['main_view'] = "purchase/View order";
		$this->load->view('layouts/main', $data);
	}

	 public function create_order() {

		$this->form_validation->set_rules('company_id', 'Company ID', 'trim|required' );
		
		if($this->form_validation->run() == FALSE){

			$last_row = $this->purchase_model->order_id();
			$data['order_id'] = $last_row + 1;
			$data['orders'] = $this->purchase_model->get_all_products();
			$data['main_view'] = 'purchase/New order';
			$this->load->view('layouts/main',$data);
		}else{
			
			 $data = array(
			 		'user_id' => $this->session->userdata('user_id'),
			 		'company_id' => $this->input->post('company_id')
					);
			if($this->purchase_model->add_order($data)) {
				redirect("purchase");
			}
		}
	}

	public function order(){
		echo "hi";
		$data = $_POST['id'];
		echo "hi";
		$orderid = $_POST['order'];
		$status = $this->purchase_model->add_order_list($data,$orderid);
		return $status;
	}

	public function get_product_price(){
		$product_id = $this->input->post('id',TRUE);
        $data = $this->purchase_model->get_price($product_id);
        echo $data->price; 
	}
}

 ?>
