<?php 

class Tasks extends CI_Controller {

	public function __construct(){

		parent::__construct();

		if(!$this->session->userdata('logged_in')){

			$this->session->set_flashdata('no_access','Sorry you are not allowed or not logged in');
			redirect('home/index');
		}
	}
	
	public function index() {

		$data['tasks'] = $this->tasks_model->get_all_task();
		$data['main_view'] = "tasks/display";
		$this->load->view('layouts/main', $data);

	}

	public function create_task() {

		$this->form_validation->set_rules('id1', 'Order ID', 'trim|required');
		$this->form_validation->set_rules('id2', 'Location', 'trim|required' );
		
		if($this->form_validation->run() == FALSE){

			$user_id = $this->session->userdata('user_id');
			$data['orders'] = $this->tasks_model->get_orders($user_id);
			$data['location'] = $this->tasks_model->get_location();
			$data['main_view'] = 'tasks/create_task';
			$this->load->view('layouts/main',$data);
		
		}else{

			$location_id =   $this->input->post('id2');
			$order_id = $this->input->post('id1');

			$data = array(
					'order_id' => $order_id,
					'location' => $location_id
					);

			$this->tasks_model->mark_complete($location_id,$order_id);

			if($this->tasks_model->create_task($data)) {

				$this->session->set_flashdata('task_created', 'Your task has been created');
				redirect("tasks");

			}
		}

	
	}

	public function edit_task($task_id) {

		$this->form_validation->set_rules('id1', 'Order ID', 'trim|required');
		$this->form_validation->set_rules('id2', 'Location', 'trim|required' );

		if($this->form_validation->run() == FALSE){


			$user_id = $this->session->userdata('user_id');
			$data['orders'] = $this->tasks_model->get_orders($user_id);
			$data['location'] = $this->tasks_model->get_location();
			$data['current_location'] = $this->tasks_model->get_location_2($task_id);
			$data['current_order'] = $this->tasks_model->get_order_id($task_id);
			$data['main_view'] = 'tasks/edit_task';
			$this->load->view('layouts/main',$data);
		
		}else{

			$data = array(
					'order_id' => $this->input->post('id1'),
					'location' => $this->input->post('id2')
				);
			
			if($this->tasks_model->edit_task($task_id,$data)) {

				$this->session->set_flashdata('task_updated', 'Your task has been updated');
				redirect("tasks");

			}
		}
	}

	public function get_task_by_id($task_id){

		

		$data['task_id'] = $task_id;
		$data['location'] = $this->tasks_model->get_location_2($task_id);
		$data['order_id'] = $this->tasks_model->get_order_id($task_id);
		$data['orders'] = $this->incoming_model->get_specific_orders($data['order_id']);
		$data['scan'] = $this->tasks_model->get_scanned_list($data['order_id']);
		$data['list'] = $this->tasks_model->comparing_lists($data['order_id']);
		$data['main_view'] = 'tasks/tasks_display_view';
		
		$this->load->view('layouts/main',$data);

	}
}

 ?>