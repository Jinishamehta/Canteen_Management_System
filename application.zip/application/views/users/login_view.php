<?php if(!$this->session->userdata('logged_in')): ?>

	<?php $attributes = array('id'=>'login_form', 'class'=> 'form_horizontal'); ?>
    <?php if($this->session->flashdata('errors')): ?>
		<?php echo $this->session->flashdata('errors'); ?>
	<?php endif; ?>
	<?php echo form_open('users/login', $attributes);?>

        <div class="form-group">
       
			<?php
				$data = array(
						'class' => 'form-control form-control-user',
						'name' => 'username',
						'placeholder' => 'Enter Username'
						);
			?>
			<?php echo form_input($data); ?>
		</div>
        <div class="form-group">

           	<?php
				$data = array(
					'class' => 'form-control form-control-user',
					'name' => 'password',
					'placeholder' => 'Enter Password'
					);
			?>
			<?php echo form_password($data); ?>
        </div>
        <div class="form-group">
			<?php 
				$data = array(
					'class' => 'btn btn-primary btn-user btn-block',
					'name' => 'submit',
					'value' => 'Login'
					);
			?>
			<?php echo form_submit($data); ?>
		</div>
        <hr>
        <a   href="<?php echo base_url();?>users/register" class="btn btn-google btn-user btn-block">
            Create an Account
        </a>
    <?php echo form_close(); ?>
<?php endif; ?>
</div>
</div> 
</div>
</div>  
</div> 
</div> 
</div>
</div>  
</div>     
</ul>
</body>
</html>

