

<h2>New Task</h2>

<?php $attributes = array('id'=>'task_form', 'class'=> 'form_horizontal'); ?>

<?php echo validation_errors("<p class='bg-danger'>"); ?>

<?php echo form_open('tasks/create_task', $attributes);?>

<div class="form-group">

			<?php echo form_label('Order ID'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
						
					$options = array_combine(
			    							array_column($orders, 'id'),
				   							array_column($orders, 'id')
								);

					$a = [];

					$data = array(

								'class' => 'form-control',
								'id' => 'id1',
								'name' => 'id1'
								
							);
				?>
			<?php echo form_dropdown('id1',$options,$a,$data) ?>
</div>

<div class="form-group">

			<?php echo form_label('Location ID'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
						
					$options = array_combine(
			    							array_column($location, 'id'),
				   							array_column($location, 'id')
								);

					$a = [];

					$data = array(

								'class' => 'form-control',
								'id' => 'id2',
								'name' => 'id2'
						
							);
				?>
			<?php echo form_dropdown('id2',$options,$a,$data) ?>
</div>



<div class="form-group">
	
	<!-- <?php //echo form_label('Password'); ?> -->
	<?php 
		$data = array(

			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Create'
		);
	?>
	<?php echo form_submit($data); ?>

</div>

<?php echo form_close(); ?>

