

<h2>Edit Task</h2>

<?php $attributes = array('id'=>'edit_task_form', 'class'=> 'form_horizontal'); ?>

<?php echo validation_errors("<p class='bg-danger'>"); ?>

<?php echo form_open('tasks/edit_task/'.$this->uri->segment(3).'', $attributes);?>




<div class="form-group">
	
	<!-- <?php //echo form_label('Password'); ?> -->
	<?php 
		$data = array(

			'class' => 'btn btn-primary',
			'name' => 'submit',
			'value' => 'Update'
		);
	?>
	<?php echo form_submit($data); ?>

</div>
<div class="form-group">

			<?php echo form_label('Order ID'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
						
					$options = array_combine(
			    							array_column($orders, 'id'),
				   							array_column($orders, 'id')
								);

					$a = [$current_order];

					$data = array(

								'class' => 'form-control',
								'id' => 'id1',
								'name' => 'id1'
								
								
							);
				?>
			<?php echo form_dropdown('id1',$options,$a,$data) ?>
</div>
<div class="form-group">

			<?php echo form_label('Location ID'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
						
					$options = array_combine(
			    							array_column($location, 'id'),
				   							array_column($location, 'id')
								);

					$a = [$current_location];

					$data = array(

								'class' => 'form-control',
								'id' => 'id2',
								'name' => 'id2'
							
						
							);
				?>
			<?php echo form_dropdown('id2',$options,$a,$data) ?>
</div>

<?php echo form_close(); ?>

