<div class="container-fluid">
  <hr>
    <div class="card shadow mb-4">
      <div class="card-body">
       	<h4><b>Task ID:</b> &nbsp;&nbsp;&nbsp;<?php echo $task_id; ?></h4>
       	<hr>
       	<h4><b>Order ID:</b>&nbsp;&nbsp;&nbsp;<?php echo $order_id; ?></h4>
       	<hr>
       	<h4><b>Location:</b>&nbsp;&nbsp;&nbsp;<?php echo $location; ?></h4>
       	<hr>
      </div>
    </div>
</div>

<div class="container-fluid">
  
  <hr>
  <!-- DataTales Example -->
  <div class="card shadow mb-4 card-body table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
        <tr>
            <th>Product_id</th>
            <th>MRP</th>
            <th>Quantity</th>
          
        </tr>
      </thead>
      <tbody>
        <?php foreach($orders as $entry): ?>
          <tr>
           <td><?php echo $entry->product_id; ?></td>
        <td><?php echo $entry->price; ?></td>
        <td><?php echo $entry->quantity; ?></td>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>


<div class="container-fluid">
  
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4 card-body table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
        <tr>
            <th>Product_id</th>
            <th>MRP</th>
            <th>Quantity</th>
          
        </tr>
      </thead>
      <tbody>
        <?php foreach($scan as $entry): ?>
          <tr>
           <td><?php echo $entry->product_id; ?></td>
        <td><?php echo $entry->price; ?></td>
        <td><?php echo $entry->quantity; ?></td>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="container-fluid">
 <hr>

 
  <!-- DataTales Example -->
  <div class="card shadow mb-4 card-body table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <thead>
        <tr>
            <th>Product_id</th>
            <th>MRP</th>
            <th>Quantity</th>
          
        </tr>
      </thead>
      <tbody>
        <?php foreach($list as $entry): ?>
          <tr>
           <td><?php echo $entry->product_id; ?></td>
        <td><?php echo $entry->price; ?></td>
        <td><?php echo $entry->quantity; ?></td>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>


  <!-- Footer -->
    <footer class="sticky-footer bg-white">
      <div class="container my-auto">
        <div class="copyright text-center my-auto">
          <span>AU1641072</span>
        </div>
      </div>
    </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="assets/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="assets/js/jquery.dataTables.min.js"></script>
  <script src="assets/js/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="assets/js/datatables-demo.js"></script>

<!--  -->
