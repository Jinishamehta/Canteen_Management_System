<p>

	<?php if($this->session->flashdata('login_failed')): ?>
	<?php echo $this->session->flashdata('login_failed');?>
	<?php endif; ?>

	<?php if($this->session->flashdata('no_access')): ?>
	<?php echo $this->session->flashdata('no_access');?>
	<?php endif; ?>

</p>

<?php if ($this->session->userdata('logged_in')): ?>
  <?php if($this->session->userdata('user_type')): ?>
 	<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Charts</h1>
    <!-- Content Row -->
    <div class="row">
      <div class="col-xl-8 col-lg-7">
      <!-- Area Chart -->
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Area Chart</h6>
          </div>
          <div class="card-body">
            <div class="chart-area">
              <canvas id="myAreaChart"></canvas>
            </div>
            <hr>
          </div>
        </div>
        <!-- Bar Chart -->
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Bar Chart</h6>
          </div>
          <div class="card-body">
            <div class="chart-bar">
              <canvas id="myBarChart"></canvas>
            </div>
            <hr>
          </div>
        </div>
      </div>
      <!-- Donut Chart -->
      <div class="col-xl-4 col-lg-5">
        <div class="card shadow mb-4">
          <!-- Card Header - Dropdown -->
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Donut Chart</h6>
          </div>
          <!-- Card Body -->
          <div class="card-body">
            <div class="chart-pie pt-4">
              <canvas id="myPieChart"></canvas>
            </div>
            <hr>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>
<!-- End of Main Content -->
<!-- Footer -->
  <footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>1641072</span>
      </div>
    </div>
  </footer>
 <!-- End of Footer -->
</div>
<!-- End of Content Wrapper -->
</div>
 <!-- End of Page Wrapper -->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url();?>assets/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url();?>assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="<?php echo base_url();?>assets/js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="<?php echo base_url();?>assets/js/chart-area-demo.js"></script>
  <script src="<?php echo base_url();?>assets/js/chart-pie-demo.js"></script>
  <script src="<?php echo base_url();?>assets/js/chart-bar-demo.js"></script>

<?php endif; ?>
</body>
</html>




