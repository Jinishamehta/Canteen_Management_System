<hr>
<h2>Add Product</h2>
<hr>
<?php $attributes = array('id'=>'product_form', 'class'=> 'form_horizontal '); ?>
	<?php echo validation_errors("<p>"); ?>
<?php echo form_open('inventory/add_product', $attributes);?>

	<div class="form-group">
		<?php

			$data = array(

				'class' => 'form-control',
				'name' => 'product_name',
				'placeholder' => 'Product Name'
				);
		?>
		<?php echo form_input($data); ?>
	</div>

	<div class="form-group">
		<?php

			$data = array(

				'class' => 'form-control',
				'name' => 'weight',
				'placeholder' => 'Weight'
				);
		?>
		<?php echo form_input($data); ?>
	</div>

	<div class="form-group">
		<?php

			$data = array(

				'class' => 'form-control',
				'name' => 'pcs',
				'placeholder' => 'pcs'
				);
		?>
		<?php echo form_input($data); ?>
	</div>

	<div class="form-group">
		<?php

			$data = array(

				'class' => 'form-control',
				'name' => 'quantity',
				'placeholder' => 'Quantity'
				);
		?>
		<?php echo form_input($data); ?>
	</div>

	<div class="form-group">
		<?php

			$data = array(

				'class' => 'form-control',
				'name' => 'price',
				'placeholder' => 'MRP'
				);
		?>
		<?php echo form_input($data); ?>
	</div>

	<?php 
		$data = array(
			'class' => 'btn btn-primary',
			'name' => 'submit',
			'id' => 'submit'
		);
	?>
	<?php echo form_submit($data,'Submit'); ?>

<?php echo form_close(); ?>

</div>

<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>AU1641072</span>
    </div>
  </div>
</footer>

<!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="assets/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="assets/js/jquery.dataTables.min.js"></script>
  <script src="assets/js/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="assets/js/datatables-demo.js"></script>
