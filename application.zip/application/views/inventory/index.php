
 <div class="container-fluid">
  <hr>
    <!-- Page Heading -->
    <?php if($this->session->userdata('user_type')): ?>
      <h1 class="h3 mb-2 text-gray-800">Products<a class="btn btn-primary float-right" href="<?php echo base_url(); ?>inventory/add_product">Add Products</a></h1>
    <?php else: ?> 
       <h1 class="h3 mb-2 text-gray-800">Products</h1>  
    <?php endif; ?>  
    <hr>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"></h6>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          	<thead>
              <tr>
                <th>Product_ID</th>
                <th>Product_Name</th>
                <th>Weight</th>
                <th>Pcs</th>
                <?php if($this->session->userdata('user_type')): ?>
                <th>Qty</th>
                <?php endif; ?>
                <th>MRP</th>
              </tr>
            </thead>
          	<tbody>
           		<?php foreach($inventory as $entry): ?>
          			<tr>
          				<td><?php echo $entry->id; ?></td>
          				<td><?php echo $entry->product_name; ?></td>
          				<td><?php echo $entry->weight; ?></td>
                  <td><?php echo $entry->pcs; ?></td>
          				
                  <?php  if($this->session->userdata('user_type')):  ?>
                    <td><?php echo $entry->quantity; ?></td>
                  <?php endif; ?>
                <td><?php echo $entry->price; ?></td>
           			</tr>
          		<?php endforeach; ?>
          	</tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>AU1641072</span>
    </div>
  </div>
</footer>

<!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="assets/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="assets/js/jquery.dataTables.min.js"></script>
  <script src="assets/js/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="assets/js/datatables-demo.js"></script>
