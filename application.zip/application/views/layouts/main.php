<!DOCTYPE  html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>User View</title>
	
  <link href="<?php echo base_url();?>assets/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

  <!-- Custom styles for this template -->
   <link href="<?php echo base_url();?>assets/css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="<?php echo base_url();?>assets/css/dataTables.bootstrap4.min.css" rel="stylesheet">

  <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">

</head>
<body id="page-top">

  <?php if($this->session->userdata('logged_in')): ?>
  <!-- Page Wrapper -->
    <div id="wrapper">
      <?php if(!$this->session->userdata('user_type')): ?>
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
          <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <div class="sidebar-brand-text mx-3">WareHouse</div>
          </a>
          <hr class="sidebar-divider my-0">
          <!-- Divider -->
          <hr class="sidebar-divider">
          <!-- Nav Item - Pages Collapse Menu -->
          <li class="nav-item">
            <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>inventory">
              <span class="sidebar-brand-text mx-3" style="font-size:20px">Products</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>purchase">
              <span  class="sidebar-brand-text mx-3" style="font-size:20px">Orders</span>
            </a>
          </li>
      <?php else: ?>

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

       <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-text mx-3">WareHouse</div>
      </a>

      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>home">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

     <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>inventory">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Inventory</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>incoming">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Purchase</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>purchase">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Order</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link  d-flex align-items-center justify-content-center" href="<?php echo base_url();?>tasks">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Tasks</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link  d-flex align-items-center justify-content-center" href="<?php echo base_url();?>users/register">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Create Admin</span></a>
      </li>

    <?php endif; ?>

      <li class="nav-item">
        <a class="nav-link d-flex align-items-center justify-content-center" href="<?php echo base_url();?>users/logout">
          <span class="sidebar-brand-text mx-3" style="font-size:20px">Logout</span>
        </a>
      </li>
    </ul>


        <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
    <?php $this->load->view($main_view); ?> 
  <?php else: ?>

    <ul class="nav navbar-nav">
      <div class="container">
      <!-- Outer Row -->
        <div class="row justify-content-center">
          <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg my-5">
              <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                  <div class="img_background col-lg-6 d-none d-lg-block" ></div>
                    <div class="col-lg-6">
                      <div class="p-5">
                        <div class="text-center">
                          <h1 class="h4 text-gray-900 mb-4">IOT Warehouse System</h1>
                        </div>
                        <?php $this->load->view($main_view); ?> 
                      
  <?php endif; ?> 
  </body>
</html>

