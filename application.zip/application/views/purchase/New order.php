<h2>Place Order</h2>
<?php $attributes = array('id'=>'order_form', 'class'=> 'form_horizontal '); ?>
<?php echo validation_errors("<p>"); ?>
<?php echo form_open('purchase/create_order', $attributes);?>

	<div class="form-group">
		<?php echo form_label('Order Id'); ?>
		<?php
			$data = array(
				'class' => 'form-control',
				'name' => 'order_id',
				'id' => 'order_id',
				'placeholder' => 'Order ID',
				'value' => $order_id
				);
		?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
			
		<?php echo form_label('Company Id'); ?>
		<?php
			$data = array(
				'class' => 'form-control',
				'name' => 'company_id',
				'placeholder' => 'Company Id'
				);
		?>
		<?php echo form_input($data); ?>
	</div>

	<?php echo form_label('Products'); ?>
	<?php 
		$data = array(
			'class' => 'btn btn-primary',
			'name' => 'submit',
			'id' => 'submit',
		);
		$js = 'onClick="add_more()"';
	?>
	<?php echo form_button($data,'Add',$js); ?>
	<hr>
	<div class = "after-add-more ">
		<div class=" form-inline">
			<div class="form-group">
				<?php echo form_label('Products'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
					$options = array_combine(
   							array_column($orders, 'id'),
   							array_column($orders, 'id')
							);
					$a = [];
					$data = array(
							'class' => 'form-control',
							'id' => 'product_id',
							'name' => 'product_id',
							'placeholder' => 'Product_id',
							'onchange' => 'get_price();'
							);
				?>
				<?php echo form_dropdown('product_id',$options,$a,$data) ?>
			</div>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<div class="form-group">
				<?php echo form_label('Price'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
					$data = array(
							'class' => 'form-control',
							'name' => 'price',
							'id' => 'price',
							'placeholder' => 'Price',
							);
				?>
				<?php echo form_input($data); ?>
			</div>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<div class="form-group">
				<?php echo form_label('Quantity'); ?>
				&nbsp;&nbsp;&nbsp;
				<?php
					$data = array(
							'class' => 'form-control',
							'name' => 'quantity',
							'id' => 'quantity',
							'placeholder' => 'Quantity',
							);
				?>
				<?php echo form_input($data); ?>
			</div>
		</div>
	</div>
	<div id="main_div" class="card shadow mb-4 card-body table-responsive">
 		<table id="AU1641072" class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			<thead>
		        <tr>
		            <th>product ID</th>
		            <th>price</th>
		            <th>Quantity</th>
		        </tr>
		    </thead>
		    <tbody></tbody>
	    </table>
	 </div>

	<?php 
		$data = array(
			'class' => 'btn btn-primary',
			'name' => 'submit',
			'id' => 'submit'
			);
		$js = 'onClick="submit_list();"';
	?>
	<?php echo form_submit($data,'Place Order',$js); ?>
</div>

 <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.3.1.js'?>"></script>
    <script type="text/javascript">

    	function get_price(){
    		var id = $('#product_id').val();
            $.ajax({
                url : "<?php echo site_url('purchase/get_product_price');?>",
                method : "POST",
                data : {id:id},
                async : true,
                dataType : 'json',
                success: function(data){
                    document.getElementById("price").value = data;
                }
            });
            return false;
    	}

    	function add_more(){
    		var product_id = $('#product_id').val(); 
       		var price = $('#price').val(); 
       		var quantity = $('#quantity').val(); 
       		$('#AU1641072 tbody:last-child').append(
       			'<tr>'+
       				'<td>'+product_id+'</td>'+
       				'<td>'+price+'</td>'+
       				'<td>'+quantity+'</td>'+
       			'</tr>'
       		);
    	}

    	function order_list(){
    		var orderList = [];
   			$('#AU1641072 tr').each(function(row,tr){
   				var td1 = $(tr).find('td:eq(0)').text();
   				var td2 = $(tr).find('td:eq(1)').text();
   				var td3 = $(tr).find('td:eq(2)').text();      		
   				var sub1 = [td1,td2,td3];
   				orderList.push(sub1);       				
   			});
      		orderList.splice(0,1);
      		return orderList;
    	}

    	function submit_list(){
    		var order_data = $('#order_id').val(); 
    		var ajax_data = order_list();
    		$.ajax({
                url: '<?php echo site_url('purchase/order');?>',
                method : "POST",
                data : {id:ajax_data,order:order_data},
                async : true,
                dataType : 'json',
                success: function(data) {
				alert("yes");
				},
				error: function(error){
					alert(error);
					console.log(error);
				}
            }); 
    	}
    </script>
<?php echo form_close(); ?>

<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>AU1641072</span>
    </div>
  </div>
</footer>

<!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="assets/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="assets/js/jquery.dataTables.min.js"></script>
  <script src="assets/js/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="assets/js/datatables-demo.js"></script>
