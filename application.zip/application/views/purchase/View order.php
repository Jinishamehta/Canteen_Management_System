<div class="container-fluid">
  <hr>
  <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800 ">Orders<a class="btn btn-primary float-right" href="<?php echo base_url(); ?>purchase/create_order">Place Order</a></h1>    
	<hr>
  <!-- DataTales Example -->
  <div class="card shadow mb-4 card-body table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    	<thead>
        <tr>
          <th>Product_id</th>
          <th>MRP</th>
          <th>Quantity</th>
        </tr>
      </thead>
    	<tbody>
    		<?php foreach($orders as $entry): ?>
		    	<tr>
				    <td><?php echo $entry->product_id; ?></td>
				    <td><?php echo $entry->price; ?></td>
				    <td><?php echo $entry->quantity; ?></td>
	   			</tr>
    		<?php endforeach; ?>
    	</tbody>
    </table>
  </div>
</div>
</div>
<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>AU1641072</span>
    </div>
  </div>
</footer>

<!-- Bootstrap core JavaScript-->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="assets/js/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="assets/js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="assets/js/jquery.dataTables.min.js"></script>
<script src="assets/js/dataTables.bootstrap4.min.js"></script>
<!-- Page level custom scripts -->
<script src="assets/js/datatables-demo.js"></script>

