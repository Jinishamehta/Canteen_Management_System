<div class="container-fluid">
    <hr>
    <!-- Page Heading -->
    <?php if($this->session->userdata('user_type')): ?>
      <h1 class="h3 mb-2 text-gray-800 ">Orders</h1>
    <?php else: ?>
      <h1 class="h3 mb-2 text-gray-800 ">Orders<a class="btn btn-primary float-right" href="<?php echo base_url(); ?>purchase/create_order">Place Order</a></h1>
  <?php endif; ?>
	<hr>
    <!-- DataTales Example -->
    <div class="card shadow mb-4 card-body table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			<thead>
        		<tr>
		            <th>Order No</th>
                <th>Client Name</th>
		            <th>Company ID</th>
		            <th>Status</th>
		            <th>Action</th>
		        </tr>
		    </thead>
			<tbody>
				<?php foreach($orders as $entry): ?>
					<tr>
						<td><?php echo $entry->id; ?></td>
            <td><?php echo $entry->first_name; ?></td>
						<td><?php echo $entry->company_id; ?></td>
						<td><?php if( $entry->status) {

							echo "Completed";
						}else{
							echo "In Progress";
						} ?></td>

						<td>
							<a href="<?php echo base_url(); ?>purchase/get_order/<?php echo $entry->id ?>" class="btn btn-success">
		                    <span class="icon text-white-50"></span>
		                    <span class="text">VIEW</span>
               	        	</a>
               	        </td>
					</tr>

				<?php endforeach; ?>
			</tbody>
		</table>
 	</div>
</div>
</div>
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>AU1641072</span>
    </div>
  </div>
</footer>
</div>
    <!-- End of Content Wrapper -->
</div>
  <!-- End of Page Wrapper -->
  <!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
   <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="assets/js/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="assets/js/jquery.dataTables.min.js"></script>
  <script src="assets/js/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="assets/js/datatables-demo.js"></script>





