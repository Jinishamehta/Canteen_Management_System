<?php
echo "Title of the blog post : ".$title;
echo "<a href='$web_Address'>"."Click here to go to blog page"."</a>";
?>